Go to about:debugging#/runtime/this-firefox
Click Load Temporary Add-on...
Browse for and select the manifest.json in this directory

Select text on a webpage and right click.. see option in menu
CTRL+SHIFT+J opens the console log window. See messages there
You might need to click the gear icon/settings then "Show Content Messages" in the Browser Console window
